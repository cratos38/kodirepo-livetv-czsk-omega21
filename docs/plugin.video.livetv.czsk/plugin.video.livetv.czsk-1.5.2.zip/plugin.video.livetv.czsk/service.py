# -*- coding: utf-8 -*-
"""
LiveTV - CZ/SK
Background service for EPG updates
"""
import os
import sys
import time
import xbmc
import xbmcaddon
import xbmcvfs

# Add lib folder to path
ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
sys.path.insert(0, os.path.join(ADDON_PATH, 'resources', 'lib'))


class LiveTVService(xbmc.Monitor):
    """Background service for LiveTV CZ/SK"""
    
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.addon = xbmcaddon.Addon()
        self.addon_id = self.addon.getAddonInfo('id')
        self.profile_path = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        
        # Create profile directory if needed
        if not os.path.exists(self.profile_path):
            os.makedirs(self.profile_path)
        
        # EPG settings
        self.epg_update_hours = 12  # Update EPG every 12 hours
        self.last_epg_update = 0
        
        self.log('Service started')
    
    def log(self, message, level=xbmc.LOGINFO):
        """Log message to Kodi log"""
        xbmc.log(f'[LiveTV CZ/SK Service] {message}', level)
    
    def onSettingsChanged(self):
        """Called when addon settings change"""
        self.addon = xbmcaddon.Addon()  # Refresh
        self.log('Settings changed')
    
    def should_update_epg(self):
        """Check if EPG needs update"""
        # Check if EPG file exists
        epg_file = os.path.join(self.profile_path, 'epg.xml')
        
        if not os.path.exists(epg_file):
            self.log('EPG file not found, update needed')
            return True
        
        # Check file age
        file_age = time.time() - os.path.getmtime(epg_file)
        max_age = self.epg_update_hours * 3600  # Convert to seconds
        
        if file_age > max_age:
            self.log('EPG file too old (%.1f hours), update needed' % (file_age / 3600))
            return True
        
        return False
    
    def update_epg(self):
        """Update EPG data"""
        try:
            from epgprocessor import update_epg as do_update
            
            self.log('Starting EPG update from IPTV-EPG.ORG...')
            
            result = do_update()
            if result:
                self.last_epg_update = time.time()
                self.log('EPG update completed successfully: %s' % result)
                return True
            else:
                self.log('EPG update failed')
                return False
                
        except Exception as e:
            self.log('EPG update error: %s' % str(e), xbmc.LOGERROR)
            import traceback
            self.log(traceback.format_exc(), xbmc.LOGERROR)
            return False
    
    def run(self):
        """Main service loop"""
        self.log('Service running')
        
        # Initial EPG update (after 30 seconds to let Kodi start)
        initial_delay = 30
        self.log('Waiting %d seconds before initial EPG check...' % initial_delay)
        
        if self.waitForAbort(initial_delay):
            return
        
        # Check and update EPG on startup
        if self.should_update_epg():
            self.update_epg()
        
        # Main loop - check every hour
        wait_time = 3600  # 1 hour
        
        while not self.abortRequested():
            # Wait for abort or timeout
            if self.waitForAbort(wait_time):
                break
            
            # Check if EPG needs update
            if self.should_update_epg():
                self.update_epg()
        
        self.log('Service stopped')


if __name__ == '__main__':
    service = LiveTVService()
    service.run()
