# -*- coding: utf-8 -*-
# Based on kodi-czsk/plugin.video.joj.sk
# License: AGPL v.3

import requests
import re

try:
    from urllib.parse import urlencode, quote
except ImportError:
    from urllib import urlencode, quote

# Channel mapping to stream names
# Format: channel_id -> stream_name for URL
CHANNELS = {
    'joj': 'joj',
    'jojplus': 'plus',
    'jojwau': 'wau',
    'joj24': 'joj_news',
    'jojko': 'jojko',
    'jojcinema': 'cinema',
    'csfilm': 'cs_film',
    'cshistory': 'cs_history',
    'csmystery': 'cs_mystery',
    'jojsport': 'joj_sport',
    'dajto': 'dajto',
    'jojfamily': 'family',
}

# Available qualities
QUALITIES = ['1080', '720', '404']

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Referer': 'https://media.joj.sk/',
    'Origin': 'https://media.joj.sk'
}


def get_live_stream(channel_id):
    """Get live stream URL for JOJ channels using andromeda CDN"""
    if channel_id not in CHANNELS:
        return None
    
    stream_name = CHANNELS[channel_id]
    
    try:
        session = requests.Session()
        session.headers.update(HEADERS)
        
        # Try each quality from highest to lowest
        for quality in QUALITIES:
            # Andromeda CDN URL format (from official kodi-czsk addon)
            url = f'https://live.cdn.joj.sk/live/andromeda/{stream_name}-{quality}.m3u8'
            
            try:
                # Test if stream is available
                response = session.head(url, timeout=5, allow_redirects=True)
                if response.status_code == 200:
                    return {
                        'url': url,
                        'manifest_type': 'hls',
                        'headers': {
                            'User-Agent': HEADERS['User-Agent'],
                            'Referer': 'https://media.joj.sk/',
                            'Origin': 'https://media.joj.sk'
                        }
                    }
            except:
                continue
        
        # If andromeda doesn't work, try alternative URL format
        for quality in QUALITIES:
            url = f'https://live.cdn.joj.sk/live/{stream_name}-{quality}.m3u8'
            
            try:
                response = session.head(url, timeout=5, allow_redirects=True)
                if response.status_code == 200:
                    return {
                        'url': url,
                        'manifest_type': 'hls',
                        'headers': {
                            'User-Agent': HEADERS['User-Agent'],
                            'Referer': 'https://media.joj.sk/',
                            'Origin': 'https://media.joj.sk'
                        }
                    }
            except:
                continue
        
        # Last resort: try without quality suffix
        url = f'https://live.cdn.joj.sk/live/andromeda/{stream_name}.m3u8'
        try:
            response = session.head(url, timeout=5, allow_redirects=True)
            if response.status_code == 200:
                return {
                    'url': url,
                    'manifest_type': 'hls',
                    'headers': {
                        'User-Agent': HEADERS['User-Agent'],
                        'Referer': 'https://media.joj.sk/',
                        'Origin': 'https://media.joj.sk'
                    }
                }
        except:
            pass
        
        return {'error': f'No working stream found for {channel_id}'}
        
    except Exception as e:
        return {'error': str(e)}
