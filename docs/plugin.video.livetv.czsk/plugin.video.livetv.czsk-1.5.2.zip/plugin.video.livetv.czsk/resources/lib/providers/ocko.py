# -*- coding: utf-8 -*-
# Based on cache-sk's freeview.sk ocko provider
# License: AGPL v.3

CHANNELS = {
    'ocko': {
        'mpd': 'https://ocko-live-dash.ssl.cdn.cra.cz/cra_live2/ocko.stream.1.smil/manifest.mpd',
        'hls': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko/playlist.m3u8'
    },
    'ockoexpres': {
        'mpd': 'https://ocko-live-dash.ssl.cdn.cra.cz/cra_live2/ocko_expres.stream.1.smil/manifest.mpd',
        'hls': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko_expres/playlist.m3u8'
    },
    'ockostar': {
        'mpd': 'https://ocko-live-dash.ssl.cdn.cra.cz/cra_live2/ocko_gold.stream.1.smil/manifest.mpd',
        'hls': 'https://ocko-live.ssl.cdn.cra.cz/channels/ocko_gold/playlist.m3u8'
    }
}

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'
}


def get_live_stream(channel_id, prefer_mpd=False):
    """Get live stream URL for Ocko channels"""
    if channel_id not in CHANNELS:
        return None
    
    channel = CHANNELS[channel_id]
    
    if prefer_mpd:
        return {
            'url': channel['mpd'],
            'manifest_type': 'mpd',
            'headers': HEADERS
        }
    else:
        return {
            'url': channel['hls'],
            'manifest_type': 'hls',
            'headers': HEADERS
        }
