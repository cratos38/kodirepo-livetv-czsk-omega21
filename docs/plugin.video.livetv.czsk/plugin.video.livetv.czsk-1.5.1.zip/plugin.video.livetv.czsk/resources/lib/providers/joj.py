# -*- coding: utf-8 -*-
# Based on cache-sk's freeview.sk joj provider
# License: AGPL v.3

import requests
import re

try:
    from urllib.parse import urlencode, quote
except ImportError:
    from urllib import urlencode, quote

CHANNELS = {
    'joj': {'base': 'https://live.joj.sk', 'iframe': 'https://media.joj.sk/', 'fget': False, 'replace': 'joj.m3u8', 'with': 'joj.m3u8'},
    'jojplus': {'base': 'https://plus.joj.sk/live', 'iframe': 'https://media.joj.sk/', 'fget': False, 'replace': 'joj.m3u8', 'with': 'plus.m3u8'},
    'jojwau': {'base': 'https://wau.joj.sk/live', 'iframe': 'https://media.joj.sk/', 'fget': False, 'replace': 'joj.m3u8', 'with': 'wau.m3u8'},
    'jojfamily': {'base': 'https://jojfamily.blesk.cz/live', 'iframe': 'https://media.joj.sk/', 'fget': True, 'replace': 'joj.m3u8', 'with': 'family.m3u8'},
    'joj24': {'base': 'https://joj24.noviny.sk/', 'iframe': 'https://media.joj.sk/', 'fget': False, 'with': 'joj_news.m3u8'},
    'jojko': {'base': 'https://live.joj.sk', 'iframe': 'https://media.joj.sk/', 'fget': False, 'replace': 'joj.m3u8', 'with': 'jojko.m3u8'},
    'jojcinema': {'base': 'https://live.joj.sk', 'iframe': 'https://media.joj.sk/', 'fget': False, 'replace': 'joj.m3u8', 'with': 'cinema.m3u8'},
    'csfilm': {'base': 'https://live.joj.sk', 'iframe': 'https://media.joj.sk/', 'fget': False, 'replace': 'joj.m3u8', 'with': 'cs_film.m3u8'},
    'cshistory': {'base': 'https://live.joj.sk', 'iframe': 'https://media.joj.sk/', 'fget': False, 'replace': 'joj.m3u8', 'with': 'cs_history.m3u8'},
    'csmystery': {'base': 'https://live.joj.sk', 'iframe': 'https://media.joj.sk/', 'fget': False, 'replace': 'joj.m3u8', 'with': 'cs_mystery.m3u8'},
    'jojsport': {'base': 'https://live.joj.sk', 'iframe': 'https://media.joj.sk/', 'fget': False, 'replace': 'joj.m3u8', 'with': 'joj_sport.m3u8'},
    'dajto': {'base': 'https://live.joj.sk', 'iframe': 'https://media.joj.sk/', 'fget': False, 'replace': 'joj.m3u8', 'with': 'dajto.m3u8'},
}

FALLBACK = "https://live.cdn.joj.sk/live/%%?loc=SK&exp=1716281798&hash=9d0862c9645f8f9ffd8736a3e732735333d1b1b665c1a9bf3db84bc8b10c0038"

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36'
}


def get_live_stream(channel_id):
    """Get live stream URL for JOJ channels"""
    if channel_id not in CHANNELS:
        return None
    
    channel = CHANNELS[channel_id]
    
    try:
        session = requests.Session()
        headers = {}
        headers.update(HEADERS)
        
        # Use fallback URL directly
        if 'with' in channel:
            hls = FALLBACK.replace("%%", channel['with'])
            
            # Pre-warm the connection
            try:
                session.get(hls, headers=headers, timeout=5)
                session.get(hls, headers=headers, timeout=5)
            except:
                pass
            
            headers = {'Referer': hls, 'Origin': hls}
            headers.update(HEADERS)
            
            return {
                'url': hls,
                'manifest_type': 'hls',
                'headers': headers
            }
    except Exception as e:
        return {'error': str(e)}
    
    return None
