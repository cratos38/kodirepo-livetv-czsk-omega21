# -*- coding: utf-8 -*-
"""
EPG Module for LiveTV - CZ/SK
Downloads and processes EPG from iptv-epg.org
"""

import os
import gzip
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import time

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    IN_KODI = True
except ImportError:
    IN_KODI = False

# EPG Sources
EPG_URL_CZ = 'https://iptv-epg.org/files/epg-cz.xml.gz'

# Channel ID mapping: our_id -> epg_id
EPG_CHANNEL_MAP = {
    # CT (Czech TV)
    'ct1': 'ČT1.cz',
    'ct2': 'ČT2.cz',
    'ct24': 'ČT24.cz',
    'ctsport': 'ČTsport.cz',
    'ctdart': 'ČT:D/ČTart.cz',
    
    # Nova
    'novacinema': 'NOVACINEMA.cz',
    
    # Prima
    'prima': 'PRIMA.cz',
    'primacool': 'PRIMACOOL.cz',
    'primamax': 'PRIMAMAX.cz',
    'primakrimi': 'PRIMAKRIMI.cz',
    'primalove': 'PRIMALOVE.cz',
    'primazoom': 'PRIMAZOOM.cz',
    'primastar': 'PRIMASTAR.cz',
    'primashow': 'PRIMASHOW.cz',
    'cnnprimanews': 'CNNPRIMANEWS.cz',
    
    # JOJ (Slovak)
    'joj': 'JOJ.cz',
    'jojplus': 'JOJPLUS.cz',
    'jojwau': 'WAU.cz',
    'jojsport': 'JOJŠPORT.cz',
    'jojfamily': 'JOJFAMILY.cz',
    'jojko': 'JOJKO.cz',
    'joj24': 'JOJ24.cz',
    'jojcinema': 'JOJCINEMA.cz',
    
    # CS Link
    'csfilm': 'CSFILM,MINI.cz',
    'cshistory': 'CSHistory.cz',
    'csmystery': 'CSMystery.cz',
    
    # RTVS (Slovak)
    'jednotka': 'JEDNOTKA.cz',
    'dvojka': 'DVOJKA.cz',
    'rtvssport': 'RTVSSPORT.cz',
    
    # TA3
    'ta3': 'TA3.cz',
    
    # Ocko (Music)
    'ocko': 'ÓČKO.cz',
    'ockoexpres': 'ÓČKOEXPRES.cz',
    'ockostar': 'ÓČKOSTAR.cz',
}


def log(msg):
    """Log message"""
    if IN_KODI:
        xbmc.log('[LiveTV CZ/SK EPG] %s' % msg, xbmc.LOGINFO)
    else:
        print('[EPG] %s' % msg)


def get_addon_path():
    """Get addon profile path"""
    if IN_KODI:
        addon = xbmcaddon.Addon()
        return xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    else:
        return os.path.dirname(os.path.abspath(__file__))


def download_epg():
    """Download EPG data from iptv-epg.org"""
    import urllib.request
    
    log('Downloading EPG from: %s' % EPG_URL_CZ)
    
    try:
        addon_path = get_addon_path()
        if not os.path.exists(addon_path):
            os.makedirs(addon_path)
        
        epg_file = os.path.join(addon_path, 'epg-cz.xml.gz')
        
        # Download with timeout
        urllib.request.urlretrieve(EPG_URL_CZ, epg_file)
        
        log('EPG downloaded: %s' % epg_file)
        return epg_file
        
    except Exception as e:
        log('ERROR downloading EPG: %s' % str(e))
        return None


def extract_epg(gz_file):
    """Extract gzipped EPG file"""
    try:
        xml_file = gz_file.replace('.gz', '')
        
        log('Extracting: %s' % gz_file)
        
        with gzip.open(gz_file, 'rb') as f_in:
            with open(xml_file, 'wb') as f_out:
                f_out.write(f_in.read())
        
        log('Extracted: %s' % xml_file)
        return xml_file
        
    except Exception as e:
        log('ERROR extracting: %s' % str(e))
        return None


def parse_epg(xml_file, channel_filter=None):
    """
    Parse EPG XML and return programme data
    
    Args:
        xml_file: Path to XML file
        channel_filter: List of EPG channel IDs to include (None = all)
    
    Returns:
        Dictionary {channel_id: [programmes]}
    """
    try:
        log('Parsing EPG: %s' % xml_file)
        
        tree = ET.parse(xml_file)
        root = tree.getroot()
        
        epg_data = {}
        
        # Get list of our EPG IDs
        our_epg_ids = set(EPG_CHANNEL_MAP.values()) if channel_filter is None else set(channel_filter)
        
        # Parse programmes
        for programme in root.findall('programme'):
            channel = programme.get('channel')
            
            # Skip channels we don't need
            if channel not in our_epg_ids:
                continue
            
            if channel not in epg_data:
                epg_data[channel] = []
            
            title_elem = programme.find('title')
            desc_elem = programme.find('desc')
            
            epg_data[channel].append({
                'start': programme.get('start'),
                'stop': programme.get('stop'),
                'title': title_elem.text if title_elem is not None and title_elem.text else '',
                'desc': desc_elem.text if desc_elem is not None and desc_elem.text else ''
            })
        
        total_programmes = sum(len(p) for p in epg_data.values())
        log('Parsed: %d channels, %d programmes' % (len(epg_data), total_programmes))
        
        return epg_data
        
    except Exception as e:
        log('ERROR parsing: %s' % str(e))
        return {}


def generate_xmltv(epg_data, output_file):
    """Generate XMLTV file for Kodi PVR"""
    try:
        log('Generating XMLTV: %s' % output_file)
        
        # Create reverse mapping (epg_id -> our_id)
        reverse_map = {v: k for k, v in EPG_CHANNEL_MAP.items()}
        
        root = ET.Element('tv')
        root.set('generator-info-name', 'LiveTV CZ/SK EPG')
        root.set('generator-info-url', 'https://github.com/cratos38/Kodirepo-LiveTV-CZ-SK-')
        
        # Add channels
        for epg_id in epg_data.keys():
            our_id = reverse_map.get(epg_id, epg_id)
            
            channel_elem = ET.SubElement(root, 'channel')
            channel_elem.set('id', our_id)
            
            display_name = ET.SubElement(channel_elem, 'display-name')
            display_name.text = our_id.upper()
        
        # Add programmes
        for epg_id, programmes in epg_data.items():
            our_id = reverse_map.get(epg_id, epg_id)
            
            for prog in programmes:
                programme_elem = ET.SubElement(root, 'programme')
                programme_elem.set('channel', our_id)
                programme_elem.set('start', prog['start'])
                programme_elem.set('stop', prog['stop'])
                
                title_elem = ET.SubElement(programme_elem, 'title')
                title_elem.set('lang', 'cs')
                title_elem.text = prog['title']
                
                if prog['desc']:
                    desc_elem = ET.SubElement(programme_elem, 'desc')
                    desc_elem.set('lang', 'cs')
                    desc_elem.text = prog['desc']
        
        # Write XML
        tree = ET.ElementTree(root)
        tree.write(output_file, encoding='utf-8', xml_declaration=True)
        
        log('XMLTV generated: %s' % output_file)
        return True
        
    except Exception as e:
        log('ERROR generating XMLTV: %s' % str(e))
        return False


def update_epg():
    """Main function to update EPG"""
    log('=' * 50)
    log('EPG UPDATE STARTED')
    log('=' * 50)
    
    # Download
    gz_file = download_epg()
    if not gz_file:
        log('EPG update FAILED: Download error')
        return False
    
    # Extract
    xml_file = extract_epg(gz_file)
    if not xml_file:
        log('EPG update FAILED: Extraction error')
        return False
    
    # Parse (only our channels)
    epg_data = parse_epg(xml_file)
    if not epg_data:
        log('EPG update FAILED: Parsing error')
        return False
    
    # Generate XMLTV
    addon_path = get_addon_path()
    output_file = os.path.join(addon_path, 'epg.xml')
    
    if not generate_xmltv(epg_data, output_file):
        log('EPG update FAILED: Generation error')
        return False
    
    # Cleanup
    try:
        os.remove(gz_file)
        os.remove(xml_file)
    except:
        pass
    
    log('=' * 50)
    log('EPG UPDATE COMPLETED')
    log('Output: %s' % output_file)
    log('=' * 50)
    
    return True


def get_epg_url():
    """Return path to generated EPG file"""
    addon_path = get_addon_path()
    return os.path.join(addon_path, 'epg.xml')


def get_current_programme(channel_id):
    """Get current programme for a channel"""
    epg_file = get_epg_url()
    
    if not os.path.exists(epg_file):
        return None
    
    try:
        tree = ET.parse(epg_file)
        root = tree.getroot()
        
        now = datetime.now()
        
        for programme in root.findall('programme'):
            if programme.get('channel') != channel_id:
                continue
            
            # Parse times (format: 20260116180000 +0100)
            start_str = programme.get('start', '')[:14]
            stop_str = programme.get('stop', '')[:14]
            
            try:
                start = datetime.strptime(start_str, '%Y%m%d%H%M%S')
                stop = datetime.strptime(stop_str, '%Y%m%d%H%M%S')
                
                if start <= now <= stop:
                    title_elem = programme.find('title')
                    desc_elem = programme.find('desc')
                    
                    return {
                        'title': title_elem.text if title_elem is not None else '',
                        'desc': desc_elem.text if desc_elem is not None else '',
                        'start': start,
                        'stop': stop
                    }
            except:
                continue
        
        return None
        
    except Exception as e:
        log('ERROR getting current programme: %s' % str(e))
        return None


if __name__ == '__main__':
    # Test
    update_epg()
