# -*- coding: utf-8 -*-
# EPG Processor para LiveTV CZ/SK usando IPTV-EPG.ORG
# Based on Freeview.sk EPG Processor
# Author: cratos38
#
# IMPORTANTE: NO remapeamos IDs!
# M3U usa: tvg-id="JEDNOTKA.cz" (igual que iptv-epg.org)
# EPG usa: channel="JEDNOTKA.cz" (sin cambiar)
# ¡ASÍ COINCIDEN!
#
# CATCHUP-ID: Se añade a cada <programme> con el título limpio
# para permitir búsqueda por nombre en catchup

import io
import os
import sys
import re
import gzip
import requests
import json
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcvfs
    import xbmcaddon
    KODI_MODE = True
except ImportError:
    KODI_MODE = False

# ==================== CONFIG ====================
EPG_URL = "https://iptv-epg.org/files/epg-cz.xml.gz"
ADDON_ID = "plugin.video.livetv.czsk"

# Lista de IDs de iptv-epg.org que nos interesan
# (los mismos que usamos en channels.py como epg_id)
WANTED_CHANNELS = [
    # RTVS (Slovak - pero iptv-epg.org usa .cz para todo!)
    "JEDNOTKA.cz",
    "DVOJKA.cz",
    "STV24.cz",
    "RTVSSPORT.cz",
    
    # JOJ (Slovak)
    "JOJ.cz",
    "JOJPLUS.cz",
    "WAU.cz",
    "JOJFAMILY.cz",
    "JOJKO.cz",
    "JOJ24.cz",
    "JOJCINEMA.cz",
    "JOJŠPORT.cz",
    
    # CS Link
    "CSFILM.cz",
    "CSFILM,MINI.cz",
    "CSHISTORY.cz",
    "CSHistory.cz",
    "CSMYSTERY.cz",
    "CSMystery.cz",
    
    # TA3
    "TA3.cz",
    
    # CT (Ceska televize)
    "ČT1.cz",
    "ČT2.cz",
    "ČT24.cz",
    "ČTsport.cz",
    "ČT:D/ČTart.cz",
    
    # Nova
    "NOVA.cz",
    "NOVACINEMA.cz",
    "NOVAACTION.cz",
    "NOVAFUN.cz",
    "NOVASPORT1.cz",
    "NOVASPORT2.cz",
    
    # Prima
    "PRIMA.cz",
    "PRIMACOOL.cz",
    "PRIMAMAX.cz",
    "PRIMAKRIMI.cz",
    "PRIMALOVE.cz",
    "PRIMAZOOM.cz",
    "PRIMASTAR.cz",
    "PRIMASHOW.cz",
    "CNNPRIMANEWS.cz",
    
    # Ocko
    "ÓČKO.cz",
    "ÓČKOEXPRES.cz",
    "ÓČKOSTAR.cz",
    
    # Markiza (por si se añade)
    "MARKIZA.cz",
    "MARKIZA_KRIMI.cz",
    "MarkizaKlasik.cz",
]

# Canales STVR que usan archivo (catchup selectivo)
STVR_CHANNELS = [
    "JEDNOTKA.cz",
    "DVOJKA.cz",
    "STV24.cz",
    "RTVSSPORT.cz",
]

# Canales con catchup completo (CT, Prima)
CATCHUP_CHANNELS = [
    "ČT1.cz",
    "ČT2.cz",
    "ČT24.cz",
    "ČTsport.cz",
    "ČT:D/ČTart.cz",
    "PRIMA.cz",
    "PRIMACOOL.cz",
    "PRIMAMAX.cz",
    "PRIMAKRIMI.cz",
    "PRIMALOVE.cz",
    "PRIMAZOOM.cz",
    "PRIMASTAR.cz",
    "PRIMASHOW.cz",
    "CNNPRIMANEWS.cz",
]

def log(message):
    """Log messages"""
    msg = "[LiveTV EPG] {}".format(message)
    if KODI_MODE:
        xbmc.log(msg, xbmc.LOGINFO)
    else:
        print(msg)


def clean_title(title):
    """
    Clean programme title for catchup-id.
    Removes markers like (P), (R), ᴺᵉʷ, etc.
    """
    if not title:
        return ""
    
    # Remove common markers
    cleaned = title
    # Remove Unicode superscript markers like ᴺᵉʷ
    cleaned = re.sub(r'[\u1D2C-\u1D6A\u2070-\u209F]+', '', cleaned)
    # Remove (P), (R), (repríza), (premiéra), etc.
    cleaned = re.sub(r'\s*\([PRpr]\)\s*', '', cleaned)
    cleaned = re.sub(r'\s*\(repríza\)\s*', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s*\(premiéra\)\s*', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s*\(premiéra\)\s*', '', cleaned, flags=re.IGNORECASE)
    # Remove trailing whitespace
    cleaned = cleaned.strip()
    
    return cleaned


def normalize_title_for_search(title):
    """Normalize title for archive search comparison"""
    if not title:
        return ""
    normalized = title.lower().strip()
    # Remove Roman numerals at the end
    normalized = re.sub(r'\s+[IVXLCDM]+\.?$', '', normalized)
    return normalized


def download_stvr_archive_index():
    """
    Download STVR archive index by scraping all letters A-Z.
    Returns dict mapping title -> {serie_id, video_id}
    """
    log("Downloading STVR archive index...")
    archive_index = {}
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'sk,cs;q=0.9,en;q=0.8',
    }
    
    letters = 'abcdefghijklmnopqrstuvwxyz9'
    
    for letter in letters:
        try:
            url = "https://www.stvr.sk/televizia/archiv?l={}".format(letter)
            response = requests.get(url, headers=headers, timeout=15)
            html = response.text
            
            # Pattern: href="/televizia/archiv/SERIE/VIDEO" ... title="TITLE"
            # Also look for class="title" elements
            pattern = r'href="/televizia/archiv/(\d+)/(\d+)"[^>]*>\s*<[^>]+class="[^"]*title[^"]*"[^>]*>([^<]+)<'
            matches = re.findall(pattern, html)
            
            if not matches:
                # Alternative pattern
                pattern2 = r'href="/televizia/archiv/(\d+)/(\d+)"[^>]*title="(?:Pozrieť v archíve )?([^"]+)"'
                matches = re.findall(pattern2, html)
            
            for serie_id, video_id, title in matches:
                title_clean = title.replace('Pozrieť v archíve ', '').strip()
                if title_clean and title_clean not in archive_index:
                    archive_index[title_clean] = {
                        'serie_id': serie_id,
                        'video_id': video_id
                    }
            
            log("  Letter {}: {} programs".format(letter, len(matches)))
            
        except Exception as e:
            log("  Error fetching letter {}: {}".format(letter, str(e)))
    
    log("STVR archive index complete: {} programs".format(len(archive_index)))
    return archive_index


def load_stvr_archive_index():
    """
    Load STVR archive index for checking which programs are available.
    If index doesn't exist or is too old, download it.
    Returns a tuple: (set of normalized titles, dict of full index)
    """
    addon_data_path = get_addon_data_path()
    index_path = os.path.join(addon_data_path, 'stvr_archive_index.json')
    
    # Check if index exists and is fresh (max 24 hours old)
    need_download = True
    if os.path.exists(index_path):
        import time
        file_age = time.time() - os.path.getmtime(index_path)
        if file_age < 86400:  # 24 hours
            need_download = False
            log("Using cached STVR archive index (age: {:.1f} hours)".format(file_age / 3600))
    
    if need_download:
        log("Downloading fresh STVR archive index...")
        archive = download_stvr_archive_index()
        
        if archive:
            # Save to cache
            try:
                if not os.path.exists(addon_data_path):
                    os.makedirs(addon_data_path)
                with open(index_path, 'w', encoding='utf-8') as f:
                    json.dump(archive, f, ensure_ascii=False, indent=2)
                log("Saved STVR archive index to: {}".format(index_path))
            except Exception as e:
                log("Error saving STVR archive index: {}".format(str(e)))
        else:
            log("Failed to download STVR archive index")
            return set(), {}
    else:
        # Load from cache
        try:
            with open(index_path, 'r', encoding='utf-8') as f:
                archive = json.load(f)
        except Exception as e:
            log("Error loading cached index: {}".format(str(e)))
            return set(), {}
    
    # Create normalized set for fast lookup
    normalized_set = set()
    for title in archive.keys():
        normalized_set.add(normalize_title_for_search(title))
    
    log("STVR archive index loaded: {} programs".format(len(normalized_set)))
    return normalized_set, archive


def is_program_in_stvr_archive(title, archive_set):
    """Check if a program title is available in STVR archive"""
    if not archive_set:
        return False
    
    normalized = normalize_title_for_search(title)
    
    # Exact match
    if normalized in archive_set:
        return True
    
    # Partial match (title contains or is contained)
    # Only check if the normalized title is long enough to be meaningful
    if len(normalized) >= 4:
        for archive_title in archive_set:
            if len(archive_title) >= 4:
                if normalized in archive_title or archive_title in normalized:
                    return True
    
    return False

def get_addon_data_path():
    """Get addon data path"""
    if KODI_MODE:
        addon = xbmcaddon.Addon(ADDON_ID)
        userdata_path = xbmcvfs.translatePath('special://userdata')
        return os.path.join(userdata_path, 'addon_data', ADDON_ID)
    else:
        return os.path.join(os.path.dirname(__file__), '..', '..', 'userdata')

def download_epg():
    """Download EPG from IPTV-EPG.ORG"""
    log("Downloading EPG from: {}".format(EPG_URL))
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(EPG_URL, headers=headers, timeout=120)
        response.raise_for_status()
        
        # Decompress gzip
        xml_data = gzip.decompress(response.content)
        
        size_mb = len(xml_data) / (1024 * 1024)
        log("Downloaded and decompressed: {:.2f} MB".format(size_mb))
        
        return xml_data
        
    except Exception as e:
        log("ERROR downloading EPG: {}".format(str(e)))
        return None

def filter_channels(xml_data):
    """Filter EPG to only include our channels and add catchup-id"""
    log("Filtering channels (keeping original IDs)...")
    log("Adding catchup-id to programmes for catchup support...")
    
    try:
        # Parse XML
        root = ET.fromstring(xml_data)
        
        # Convert to sets for faster lookup
        wanted_set = set(WANTED_CHANNELS)
        stvr_set = set(STVR_CHANNELS)
        catchup_set = set(CATCHUP_CHANNELS)
        
        # Load STVR archive index for selective catchup
        stvr_archive_set, stvr_archive_full = load_stvr_archive_index()
        
        channels_kept = 0
        channels_removed = 0
        programmes_kept = 0
        programmes_removed = 0
        catchup_added = 0
        stvr_catchup_added = 0
        stvr_catchup_skipped = 0
        
        # Filter <channel> elements - keep only wanted ones
        channels_to_remove = []
        for channel in root.findall('channel'):
            channel_id = channel.get('id')
            
            if channel_id in wanted_set:
                channels_kept += 1
                display_name = channel.find('display-name')
                ch_name = display_name.text if display_name is not None else channel_id
                log("  Keeping: {} ({})".format(ch_name, channel_id))
            else:
                channels_to_remove.append(channel)
                channels_removed += 1
        
        # Remove unwanted channels
        for channel in channels_to_remove:
            root.remove(channel)
        
        # Filter <programme> elements and add catchup-id
        programmes_to_remove = []
        for programme in root.findall('programme'):
            channel_id = programme.get('channel')
            
            if channel_id in wanted_set:
                programmes_kept += 1
                
                # Get programme title
                title_elem = programme.find('title')
                if title_elem is not None and title_elem.text:
                    original_title = title_elem.text
                    cleaned_title = clean_title(original_title)
                    
                    # Add catchup-id based on channel type
                    if channel_id in catchup_set:
                        # CT/Prima: always add catchup-id
                        programme.set('catchup-id', cleaned_title)
                        catchup_added += 1
                    elif channel_id in stvr_set:
                        # STVR: only add if program is in archive
                        if is_program_in_stvr_archive(cleaned_title, stvr_archive_set):
                            programme.set('catchup-id', cleaned_title)
                            stvr_catchup_added += 1
                        else:
                            stvr_catchup_skipped += 1
            else:
                programmes_to_remove.append(programme)
                programmes_removed += 1
        
        # Remove unwanted programmes
        for programme in programmes_to_remove:
            root.remove(programme)
        
        log("Channels kept: {}".format(channels_kept))
        log("Channels removed: {}".format(channels_removed))
        log("Programmes kept: {}".format(programmes_kept))
        log("Programmes removed: {}".format(programmes_removed))
        log("Catchup-id added (CT/Prima): {}".format(catchup_added))
        log("Catchup-id added (STVR archive): {}".format(stvr_catchup_added))
        log("Catchup-id skipped (STVR not in archive): {}".format(stvr_catchup_skipped))
        
        # Convert back to XML string
        xml_str = ET.tostring(root, encoding='utf-8', xml_declaration=True)
        
        return xml_str
        
    except Exception as e:
        log("ERROR filtering: {}".format(str(e)))
        import traceback
        log(traceback.format_exc())
        return None

def update_epg():
    """Main function to update EPG"""
    log("=" * 50)
    log("Starting EPG update from IPTV-EPG.ORG")
    log("NOTE: Keeping original IDs (no remapping)")
    log("=" * 50)
    
    # Download EPG
    xml_data = download_epg()
    if not xml_data:
        log("Failed to download EPG")
        return None
    
    # Filter channels (NO remapping - keep original IDs!)
    filtered_xml = filter_channels(xml_data)
    if not filtered_xml:
        log("Failed to filter channels")
        return None
    
    # Get addon data path
    addon_data_path = get_addon_data_path()
    log("Target directory: {}".format(addon_data_path))
    
    # Create directory if not exists
    if not os.path.exists(addon_data_path):
        try:
            os.makedirs(addon_data_path)
            log("Created directory: {}".format(addon_data_path))
        except Exception as e:
            log("ERROR creating directory: {}".format(str(e)))
            return None
    
    # EPG file path
    epg_path = os.path.join(addon_data_path, 'epg.xml')
    
    try:
        # Remove old file if exists
        if os.path.exists(epg_path):
            try:
                os.remove(epg_path)
                log("Removed old epg.xml")
            except:
                pass
        
        # Write EPG file
        with io.open(epg_path, 'wb') as f:
            f.write(filtered_xml)
        
        # Verify file was written
        if os.path.exists(epg_path):
            size_mb = os.path.getsize(epg_path) / (1024 * 1024)
            log("=" * 50)
            log("SUCCESS! EPG saved: {}".format(epg_path))
            log("File size: {:.2f} MB".format(size_mb))
            log("=" * 50)
            return epg_path
        else:
            log("ERROR: File was not created!")
            return None
        
    except Exception as e:
        log("ERROR saving EPG: {}".format(str(e)))
        import traceback
        log(traceback.format_exc())
        return None

def get_epg_path():
    """Get path to EPG file"""
    addon_data_path = get_addon_data_path()
    return os.path.join(addon_data_path, 'epg.xml')

def epg_exists():
    """Check if EPG file exists"""
    return os.path.exists(get_epg_path())

def get_epg_age_hours():
    """Get age of EPG file in hours"""
    epg_path = get_epg_path()
    if not os.path.exists(epg_path):
        return float('inf')
    
    import time
    file_time = os.path.getmtime(epg_path)
    age_seconds = time.time() - file_time
    return age_seconds / 3600

# Compatibility functions for Freeview-style API
def get_epg(channels, from_date, days=7, recalculate=True):
    """Freeview-compatible EPG function"""
    return update_epg()

def generate_xmltv(channels, epg, path):
    """Not used - IPTV-EPG.ORG already provides XMLTV"""
    pass

def generate_plot(epg, now, chtitle, items_left=3):
    """Not used in this mode"""
    return ""

def tidy_epg(epg_info):
    """Not used in this mode"""
    return epg_info

# Test standalone
if __name__ == '__main__':
    print("=" * 60)
    print("EPG PROCESSOR - LiveTV CZ/SK")
    print("Source: IPTV-EPG.ORG")
    print("Mode: FILTER ONLY (no ID remapping)")
    print("=" * 60)
    
    result = update_epg()
    
    if result:
        print("\n" + "=" * 60)
        print("SUCCESS!")
        print("EPG file: {}".format(result))
        print("=" * 60)
        print("\nIDs in EPG match iptv-epg.org IDs:")
        print("  JEDNOTKA.cz, JOJ.cz, ČT1.cz, PRIMA.cz, etc.")
        print("\nM3U must use same IDs in tvg-id attribute!")
    else:
        print("\n" + "=" * 60)
        print("FAILED!")
        print("=" * 60)
