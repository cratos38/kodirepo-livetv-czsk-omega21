# -*- coding: utf-8 -*-
"""
Channel definitions for LiveTV - CZ/SK
Based on Freeview.sk playlist - only channels that work
With EPG IDs from iptv-epg.org
"""

CHANNELS = {
    # ============ STVR (Slovak) - WORKING + CATCHUP ============
    'jednotka': {
        'name': 'Jednotka',
        'provider': 'stvr',
        'country': 'SK',
        'group': 'STVR',
        'logo': 'jednotka.png',
        'epg_id': 'JEDNOTKA.cz',
        'catchup': True,
        'catchup_days': 7,
        'catchup_type': 'archive',  # Uses archive index, not all programs available
    },
    'dvojka': {
        'name': 'Dvojka',
        'provider': 'stvr',
        'country': 'SK',
        'group': 'STVR',
        'logo': 'dvojka.png',
        'epg_id': 'DVOJKA.cz',
        'catchup': True,
        'catchup_days': 7,
        'catchup_type': 'archive',
    },
    'trojka': {
        'name': 'Trojka',
        'provider': 'stvr',
        'country': 'SK',
        'group': 'STVR',
        'logo': 'trojka.png',
        'epg_id': '',
        'catchup': True,
        'catchup_days': 7,
        'catchup_type': 'archive',
    },
    'stv24': {
        'name': ':24',
        'provider': 'stvr',
        'country': 'SK',
        'group': 'STVR',
        'logo': '24.png',
        'epg_id': '',
        'catchup': True,
        'catchup_days': 7,
        'catchup_type': 'archive',
    },
    'stvrsport': {
        'name': 'STVR Sport',
        'provider': 'stvr',
        'country': 'SK',
        'group': 'STVR',
        'logo': 'sport.png',
        'epg_id': 'RTVSSPORT.cz',
        'catchup': True,
        'catchup_days': 7,
        'catchup_type': 'archive',
    },
    'stvronline': {
        'name': 'Live :O',
        'provider': 'stvr',
        'country': 'SK',
        'group': 'STVR',
        'logo': 'stvr.png',
        'epg_id': '',
    },
    'stvrlive': {
        'name': 'Live STVR',
        'provider': 'stvr',
        'country': 'SK',
        'group': 'STVR',
        'logo': 'stvr.png',
        'epg_id': '',
    },
    'nrsr': {
        'name': 'Live NRSR',
        'provider': 'stvr',
        'country': 'SK',
        'group': 'STVR',
        'logo': 'nrsr.png',
        'epg_id': '',
    },
    
    # ============ JOJ (Slovak) - WORKING ============
    'joj': {
        'name': 'JOJ',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'joj.png',
        'epg_id': 'JOJ.cz',
    },
    'jojplus': {
        'name': 'JOJ Plus',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'plus.png',
        'epg_id': 'JOJPLUS.cz',
    },
    'jojwau': {
        'name': 'WAU',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'wau.png',
        'epg_id': 'WAU.cz',
    },
    'jojsport': {
        'name': 'JOJ Sport',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojsport.png',
        'epg_id': 'JOJŠPORT.cz',
    },
    'jojfamily': {
        'name': 'JOJ Family',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'family.png',
        'epg_id': 'JOJFAMILY.cz',
    },
    'jojko': {
        'name': 'JOJko',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojko.png',
        'epg_id': 'JOJKO.cz',
    },
    'joj24': {
        'name': 'JOJ 24',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'joj24.png',
        'epg_id': 'JOJ24.cz',
    },
    'jojcinema': {
        'name': 'JOJ Cinema',
        'provider': 'joj',
        'country': 'SK',
        'group': 'JOJ',
        'logo': 'jojcinema.png',
        'epg_id': 'JOJCINEMA.cz',
    },
    
    # ============ CS LINK (via JOJ) - WORKING ============
    'csfilm': {
        'name': 'CS Film',
        'provider': 'joj',
        'country': 'CZ',
        'group': 'CS Link',
        'logo': 'csfilm.png',
        'epg_id': 'CSFILM,MINI.cz',
    },
    'cshistory': {
        'name': 'CS History',
        'provider': 'joj',
        'country': 'CZ',
        'group': 'CS Link',
        'logo': 'cshistory.png',
        'epg_id': 'CSHistory.cz',
    },
    'csmystery': {
        'name': 'CS Mystery',
        'provider': 'joj',
        'country': 'CZ',
        'group': 'CS Link',
        'logo': 'csmystery.png',
        'epg_id': 'CSMystery.cz',
    },
    
    # ============ TA3 (Slovak News) - WORKING ============
    'ta3': {
        'name': 'TA3',
        'provider': 'ta3',
        'country': 'SK',
        'group': 'News',
        'logo': 'ta3.png',
        'epg_id': 'TA3.cz',
    },
    
    # ============ CESKA TELEVIZE (CT) - WORKING + CATCHUP ============
    'ct1': {
        'name': 'CT1',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ct1.png',
        'epg_id': 'ČT1.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'ct2': {
        'name': 'CT2',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ct2.png',
        'epg_id': 'ČT2.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'ct24': {
        'name': 'CT24',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ct24.png',
        'epg_id': 'ČT24.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'ctsport': {
        'name': 'CT Sport',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ctsport.png',
        'epg_id': 'ČTsport.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'ctdart': {
        'name': 'CT :D/art',
        'provider': 'ct',
        'country': 'CZ',
        'group': 'Ceska televize',
        'logo': 'ctdart.png',
        'epg_id': 'ČT:D/ČTart.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    
    # ============ NOVA - WORKING (with IP spoof) ============
    'novacinema': {
        'name': 'Nova Cinema',
        'provider': 'nova',
        'country': 'CZ',
        'group': 'Nova',
        'logo': 'novacinema.png',
        'epg_id': 'NOVACINEMA.cz',
    },
    
    # ============ PRIMA - WORKING (via proxy) + CATCHUP ============
    'prima': {
        'name': 'Prima',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'prima.png',
        'epg_id': 'PRIMA.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'primacool': {
        'name': 'Prima Cool',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primacool.png',
        'epg_id': 'PRIMACOOL.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'primamax': {
        'name': 'Prima Max',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primamax.png',
        'epg_id': 'PRIMAMAX.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'primakrimi': {
        'name': 'Prima Krimi',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primakrimi.png',
        'epg_id': 'PRIMAKRIMI.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'primalove': {
        'name': 'Prima Love',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primalove.png',
        'epg_id': 'PRIMALOVE.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'primazoom': {
        'name': 'Prima Zoom',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primazoom.png',
        'epg_id': 'PRIMAZOOM.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'primastar': {
        'name': 'Prima Star',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primastar.png',
        'epg_id': 'PRIMASTAR.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'primashow': {
        'name': 'Prima Show',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'primashow.png',
        'epg_id': 'PRIMASHOW.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    'cnnprimanews': {
        'name': 'CNN Prima News',
        'provider': 'prima',
        'country': 'CZ',
        'group': 'Prima',
        'logo': 'cnnprimanews.png',
        'epg_id': 'CNNPRIMANEWS.cz',
        'catchup': True,
        'catchup_days': 7,
    },
    
    # ============ OCKO (Music) - WORKING ============
    'ocko': {
        'name': 'Ocko',
        'provider': 'ocko',
        'country': 'CZ',
        'group': 'Music',
        'logo': 'ocko.png',
        'epg_id': 'ÓČKO.cz',
    },
    'ockoexpres': {
        'name': 'Ocko Expres',
        'provider': 'ocko',
        'country': 'CZ',
        'group': 'Music',
        'logo': 'ockoexpress.png',
        'epg_id': 'ÓČKOEXPRES.cz',
    },
    'ockostar': {
        'name': 'Ocko Star',
        'provider': 'ocko',
        'country': 'CZ',
        'group': 'Music',
        'logo': 'ockostar.png',
        'epg_id': 'ÓČKOSTAR.cz',
    },
    
    # ============ OTHER - WORKING ============
    'fashion': {
        'name': 'Fashion TV',
        'provider': 'simple',
        'country': 'INT',
        'group': 'Other',
        'logo': 'fashion.png',
        'epg_id': '',
    },
    'doktor': {
        'name': 'TV Doktor',
        'provider': 'simple',
        'country': 'SK',
        'group': 'Other',
        'logo': 'drtv.png',
        'epg_id': '',
    },
    'szts': {
        'name': 'SZTS',
        'provider': 'simple',
        'country': 'SK',
        'group': 'Other',
        'logo': 'szts.png',
        'epg_id': '',
    },
}


def get_all_channels():
    """Return all channels sorted alphabetically"""
    return dict(sorted(CHANNELS.items(), key=lambda x: x[1]['name'].lower()))


def get_channel(channel_id):
    """Get channel info by ID"""
    return CHANNELS.get(channel_id)


def get_epg_ids():
    """Return dictionary of channel_id -> epg_id mappings"""
    return {k: v.get('epg_id', '') for k, v in CHANNELS.items() if v.get('epg_id')}
