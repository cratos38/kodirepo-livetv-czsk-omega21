# -*- coding: utf-8 -*-
"""
Radio CZ/SK - Kodi Plugin v1.1.0
Czech and Slovak Internet Radio Stations
Uses Radio Browser API for 400+ stations
"""

import sys
import os
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from urllib.parse import urlencode, parse_qsl
from urllib.request import urlopen, Request
from urllib.error import URLError

# Plugin info
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ADDON_DATA = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

# Only set HANDLE and BASE_URL when running as plugin (not when imported by service)
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ''

# Radio Browser API
RADIO_BROWSER_API = 'https://de1.api.radio-browser.info/json'

# Ensure data directory exists
if not xbmcvfs.exists(ADDON_DATA):
    xbmcvfs.mkdirs(ADDON_DATA)

# Cache file for stations
CACHE_FILE = os.path.join(ADDON_DATA, 'stations_cache.json')
M3U_FILE = os.path.join(ADDON_DATA, 'radio_czsk.m3u')
BUNDLED_M3U = os.path.join(ADDON_PATH, 'resources', 'radio_czsk.m3u')

# ============================================================================
# RADIO BROWSER API FUNCTIONS
# ============================================================================

def fetch_from_api(endpoint, params=None):
    """Fetch data from Radio Browser API"""
    try:
        url = f'{RADIO_BROWSER_API}/{endpoint}'
        if params:
            url += '?' + urlencode(params)
        
        req = Request(url)
        req.add_header('User-Agent', f'Kodi/{ADDON_ID}/1.1.0')
        
        with urlopen(req, timeout=15) as response:
            return json.loads(response.read().decode('utf-8'))
    except URLError as e:
        xbmc.log(f'{ADDON_ID}: API Error: {str(e)}', xbmc.LOGERROR)
        return None
    except Exception as e:
        xbmc.log(f'{ADDON_ID}: Error: {str(e)}', xbmc.LOGERROR)
        return None


def fetch_stations_by_country(country_code, limit=500):
    """Fetch radio stations by country code"""
    params = {
        'countrycode': country_code,
        'hidebroken': 'true',
        'order': 'votes',
        'reverse': 'true',
        'limit': limit
    }
    return fetch_from_api('stations/bycountrycode', params)


def fetch_all_czsk_stations():
    """Fetch all Czech and Slovak stations from Radio Browser API"""
    xbmc.log(f'{ADDON_ID}: Fetching stations from Radio Browser API...', xbmc.LOGINFO)
    
    cz_stations = fetch_stations_by_country('CZ', 300) or []
    sk_stations = fetch_stations_by_country('SK', 200) or []
    
    all_stations = []
    
    # Process Czech stations
    for s in cz_stations:
        all_stations.append({
            'stationuuid': s.get('stationuuid', ''),
            'name': s.get('name', 'Unknown'),
            'stream': s.get('url_resolved', s.get('url', '')),
            'logo': s.get('favicon', ''),
            'genre': (s.get('tags', '') or '').split(',')[0] if s.get('tags') else 'Radio',
            'country': 'CZ',
            'group': categorize_cz_station(s.get('name', '')),
            'votes': s.get('votes', 0),
            'bitrate': s.get('bitrate', 0),
        })
    
    # Process Slovak stations
    for s in sk_stations:
        all_stations.append({
            'stationuuid': s.get('stationuuid', ''),
            'name': s.get('name', 'Unknown'),
            'stream': s.get('url_resolved', s.get('url', '')),
            'logo': s.get('favicon', ''),
            'genre': (s.get('tags', '') or '').split(',')[0] if s.get('tags') else 'Radio',
            'country': 'SK',
            'group': categorize_sk_station(s.get('name', '')),
            'votes': s.get('votes', 0),
            'bitrate': s.get('bitrate', 0),
        })
    
    xbmc.log(f'{ADDON_ID}: Fetched {len(all_stations)} stations ({len(cz_stations)} CZ, {len(sk_stations)} SK)', xbmc.LOGINFO)
    return all_stations


def categorize_cz_station(name):
    """Categorize Czech station by name"""
    name_lower = name.lower()
    if 'rozhlas' in name_lower or 'čro' in name_lower or 'cro ' in name_lower:
        if any(r in name_lower for r in ['brno', 'ostrava', 'plzeň', 'plzen', 'region', 'budějov', 'liberec', 'hradec', 'olomouc', 'pardubice', 'karlovy', 'zlín', 'vysočin']):
            return 'Český rozhlas Regional'
        return 'Český rozhlas'
    return 'České rádio'


def categorize_sk_station(name):
    """Categorize Slovak station by name"""
    name_lower = name.lower()
    if 'stvr' in name_lower or 'rtvs' in name_lower or 'slovensko' in name_lower or 'regina' in name_lower or 'devín' in name_lower or 'devin' in name_lower or 'patria' in name_lower:
        return 'STVR'
    return 'Slovenské rádio'


# ============================================================================
# CACHE FUNCTIONS
# ============================================================================

def save_cache(stations):
    """Save stations to cache file"""
    try:
        cache_data = {
            'timestamp': xbmc.getInfoLabel('System.Date') + ' ' + xbmc.getInfoLabel('System.Time'),
            'stations': stations
        }
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, ensure_ascii=False, indent=2)
        xbmc.log(f'{ADDON_ID}: Cache saved with {len(stations)} stations', xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f'{ADDON_ID}: Error saving cache: {str(e)}', xbmc.LOGERROR)
        return False


def load_cache():
    """Load stations from cache file"""
    try:
        if os.path.exists(CACHE_FILE):
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
            return cache_data.get('stations', [])
    except Exception as e:
        xbmc.log(f'{ADDON_ID}: Error loading cache: {str(e)}', xbmc.LOGERROR)
    return None


def get_stations(force_refresh=False):
    """Get stations from cache or API"""
    if not force_refresh:
        cached = load_cache()
        if cached:
            xbmc.log(f'{ADDON_ID}: Loaded {len(cached)} stations from cache', xbmc.LOGINFO)
            return cached
    
    # Fetch from API
    stations = fetch_all_czsk_stations()
    if stations:
        save_cache(stations)
        return stations
    
    # If API fails and no cache, try bundled M3U
    return load_bundled_stations()


def load_bundled_stations():
    """Load stations from bundled M3U file"""
    if not os.path.exists(BUNDLED_M3U):
        return []
    
    stations = []
    try:
        with open(BUNDLED_M3U, 'r', encoding='utf-8') as f:
            content = f.read()
        
        lines = content.strip().split('\n')
        current_info = None
        
        for line in lines:
            if line.startswith('#EXTINF:'):
                # Parse EXTINF line
                current_info = line
            elif line.startswith('http') and current_info:
                # Parse station info
                name = current_info.split(',')[-1].strip() if ',' in current_info else 'Unknown'
                
                # Extract attributes
                tvg_id = ''
                tvg_logo = ''
                group = 'Radio CZ/SK'
                
                if 'tvg-id="' in current_info:
                    tvg_id = current_info.split('tvg-id="')[1].split('"')[0]
                if 'tvg-logo="' in current_info:
                    tvg_logo = current_info.split('tvg-logo="')[1].split('"')[0]
                if 'group-title="' in current_info:
                    group = current_info.split('group-title="')[1].split('"')[0]
                
                stations.append({
                    'stationuuid': tvg_id,
                    'name': name,
                    'stream': line.strip(),
                    'logo': tvg_logo,
                    'genre': 'Radio',
                    'country': 'CZ' if 'čes' in group.lower() or 'cz' in group.lower() else 'SK',
                    'group': group,
                    'votes': 0,
                    'bitrate': 128,
                })
                current_info = None
        
        xbmc.log(f'{ADDON_ID}: Loaded {len(stations)} stations from bundled M3U', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'{ADDON_ID}: Error loading bundled M3U: {str(e)}', xbmc.LOGERROR)
    
    return stations


# ============================================================================
# M3U PLAYLIST GENERATOR
# ============================================================================

def generate_m3u(stations=None, radio_type=True):
    """Generate M3U playlist content"""
    if stations is None:
        stations = get_stations()
    
    lines = ['#EXTM3U']
    
    for station in stations:
        name = station['name']
        stream = station['stream']
        logo = station.get('logo', '')
        group = station.get('group', 'Radio CZ/SK')
        station_id = station.get('stationuuid', name.lower().replace(' ', '-'))
        
        # Add radio=true for PVR IPTV Simple Client to show in Radio section
        if radio_type:
            extinf = f'#EXTINF:-1 radio="true" tvg-id="{station_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}'
        else:
            extinf = f'#EXTINF:-1 tvg-id="{station_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}'
        
        lines.append(extinf)
        lines.append(stream)
    
    return '\n'.join(lines)


def save_m3u_playlist(path=None):
    """Save M3U playlist to file"""
    if path is None:
        path = M3U_FILE
    
    stations = get_stations()
    m3u_content = generate_m3u(stations)
    
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(m3u_content)
        xbmc.log(f'{ADDON_ID}: M3U playlist saved to {path} ({len(stations)} stations)', xbmc.LOGINFO)
        return path, len(stations)
    except Exception as e:
        xbmc.log(f'{ADDON_ID}: Error saving M3U: {str(e)}', xbmc.LOGERROR)
        return None, 0


# ============================================================================
# KODI UI FUNCTIONS
# ============================================================================

def build_url(query):
    """Build plugin URL with parameters"""
    return f'{BASE_URL}?{urlencode(query)}'


def show_main_menu():
    """Show main menu with categories"""
    categories = [
        ('all', '📻 Všechny stanice / All Stations', 'DefaultMusicCompilations.png'),
        ('cro', '🇨🇿 Český rozhlas', 'DefaultMusicCompilations.png'),
        ('cro_regional', '🏘️ Český rozhlas Regional', 'DefaultMusicCompilations.png'),
        ('cz_other', '🎵 České rádio (ostatní)', 'DefaultMusicCompilations.png'),
        ('stvr', '🇸🇰 STVR / RTVS', 'DefaultMusicCompilations.png'),
        ('sk_other', '🎶 Slovenské rádio (ostatní)', 'DefaultMusicCompilations.png'),
        ('separator1', '───────────────────', 'DefaultFolder.png'),
        ('cz', '🇨🇿 Všechny české', 'DefaultMusicCompilations.png'),
        ('sk', '🇸🇰 Všechny slovenské', 'DefaultMusicCompilations.png'),
        ('separator2', '───────────────────', 'DefaultFolder.png'),
        ('search', '🔍 Hledat / Search', 'DefaultAddonsSearch.png'),
        ('generate_m3u', '📋 Generovat M3U playlist', 'DefaultFile.png'),
        ('refresh', '🔄 Aktualizovat stanice z internetu', 'DefaultAddonsUpdates.png'),
        ('settings', '⚙️ Nastavení / Settings', 'DefaultAddonProgram.png'),
    ]
    
    for cat_id, cat_name, icon in categories:
        if cat_id.startswith('separator'):
            li = xbmcgui.ListItem(label=cat_name)
            li.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(HANDLE, '', li, isFolder=False)
        else:
            li = xbmcgui.ListItem(label=cat_name)
            li.setArt({'icon': icon, 'thumb': icon})
            url = build_url({'action': 'category', 'category': cat_id})
            is_folder = cat_id not in ['generate_m3u', 'settings', 'refresh']
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)
    
    xbmcplugin.endOfDirectory(HANDLE)


def show_stations(category):
    """Show stations for a category"""
    stations = get_stations()
    
    if category == 'all':
        filtered = stations
    elif category == 'cro':
        filtered = [s for s in stations if s['group'] == 'Český rozhlas']
    elif category == 'cro_regional':
        filtered = [s for s in stations if s['group'] == 'Český rozhlas Regional']
    elif category == 'cz_other':
        filtered = [s for s in stations if s['country'] == 'CZ' and 'rozhlas' not in s['group'].lower()]
    elif category == 'stvr':
        filtered = [s for s in stations if s['group'] == 'STVR']
    elif category == 'sk_other':
        filtered = [s for s in stations if s['country'] == 'SK' and s['group'] != 'STVR']
    elif category == 'cz':
        filtered = [s for s in stations if s['country'] == 'CZ']
    elif category == 'sk':
        filtered = [s for s in stations if s['country'] == 'SK']
    else:
        filtered = stations
    
    for station in filtered:
        li = xbmcgui.ListItem(label=station['name'])
        li.setArt({
            'icon': station.get('logo', 'DefaultAudio.png') or 'DefaultAudio.png',
            'thumb': station.get('logo', 'DefaultAudio.png') or 'DefaultAudio.png',
            'fanart': os.path.join(ADDON_PATH, 'resources', 'media', 'fanart.jpg')
        })
        li.setInfo('music', {
            'title': station['name'],
            'genre': station.get('genre', ''),
            'artist': station.get('group', ''),
        })
        li.setProperty('IsPlayable', 'true')
        
        # Add context menu
        context_items = [
            ('Přidat do oblíbených', f'RunPlugin({build_url({"action": "add_favorite", "station_id": station["stationuuid"]})})'),
        ]
        li.addContextMenuItems(context_items)
        
        url = build_url({'action': 'play', 'station_id': station['stationuuid']})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    
    xbmcplugin.setContent(HANDLE, 'songs')
    xbmcplugin.endOfDirectory(HANDLE)


def search_stations():
    """Search stations by name"""
    keyboard = xbmc.Keyboard('', 'Zadejte hledaný výraz / Enter search term')
    keyboard.doModal()
    
    if keyboard.isConfirmed():
        search_term = keyboard.getText().lower()
        if search_term:
            stations = get_stations()
            results = [s for s in stations if search_term in s['name'].lower()]
            
            if results:
                for station in results:
                    li = xbmcgui.ListItem(label=f"{station['name']} [{station['country']}]")
                    li.setArt({
                        'icon': station.get('logo', 'DefaultAudio.png') or 'DefaultAudio.png',
                        'thumb': station.get('logo', 'DefaultAudio.png') or 'DefaultAudio.png',
                    })
                    li.setProperty('IsPlayable', 'true')
                    url = build_url({'action': 'play', 'station_id': station['stationuuid']})
                    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
                
                xbmcplugin.setContent(HANDLE, 'songs')
                xbmcplugin.endOfDirectory(HANDLE)
            else:
                xbmcgui.Dialog().notification(ADDON_NAME, f'Nenalezeno: {search_term}', xbmcgui.NOTIFICATION_INFO)


def play_station(station_id):
    """Play a radio station"""
    stations = get_stations()
    station = next((s for s in stations if s['stationuuid'] == station_id), None)
    
    if station:
        li = xbmcgui.ListItem(path=station['stream'])
        li.setArt({
            'icon': station.get('logo', 'DefaultAudio.png') or 'DefaultAudio.png',
            'thumb': station.get('logo', 'DefaultAudio.png') or 'DefaultAudio.png',
            'fanart': os.path.join(ADDON_PATH, 'resources', 'media', 'fanart.jpg')
        })
        li.setInfo('music', {
            'title': station['name'],
            'genre': station.get('genre', ''),
            'artist': station.get('group', ''),
        })
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Stanice nenalezena / Station not found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def show_generate_m3u_dialog():
    """Show dialog and generate M3U playlist"""
    pDialog = xbmcgui.DialogProgress()
    pDialog.create(ADDON_NAME, 'Generuji M3U playlist...')
    pDialog.update(50)
    
    m3u_path, count = save_m3u_playlist()
    
    pDialog.close()
    
    if m3u_path:
        dialog = xbmcgui.Dialog()
        dialog.ok(
            ADDON_NAME,
            f'M3U playlist byl vygenerován!\n\n'
            f'📻 Počet stanic: {count}\n'
            f'📁 Cesta: {m3u_path}\n\n'
            f'Použijte tuto cestu v nastavení PVR IPTV Simple Client.'
        )
    else:
        xbmcgui.Dialog().notification(ADDON_NAME, 'Chyba při generování M3U', xbmcgui.NOTIFICATION_ERROR)


def refresh_stations():
    """Refresh stations from API"""
    pDialog = xbmcgui.DialogProgress()
    pDialog.create(ADDON_NAME, 'Aktualizuji stanice z Radio Browser API...')
    pDialog.update(30)
    
    stations = fetch_all_czsk_stations()
    
    pDialog.update(70, 'Ukládám do cache...')
    
    if stations:
        save_cache(stations)
        pDialog.close()
        xbmcgui.Dialog().notification(
            ADDON_NAME, 
            f'Aktualizováno: {len(stations)} stanic',
            xbmcgui.NOTIFICATION_INFO
        )
    else:
        pDialog.close()
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Chyba při aktualizaci',
            xbmcgui.NOTIFICATION_ERROR
        )


# ============================================================================
# MAIN ROUTER
# ============================================================================

def router(paramstring):
    """Route plugin calls"""
    params = dict(parse_qsl(paramstring))
    action = params.get('action')
    
    if not action:
        show_main_menu()
    elif action == 'category':
        category = params.get('category', 'all')
        if category == 'generate_m3u':
            show_generate_m3u_dialog()
        elif category == 'settings':
            ADDON.openSettings()
        elif category == 'refresh':
            refresh_stations()
        elif category == 'search':
            search_stations()
        elif category.startswith('separator'):
            pass  # Do nothing for separators
        else:
            show_stations(category)
    elif action == 'play':
        station_id = params.get('station_id')
        if station_id:
            play_station(station_id)
    elif action == 'refresh':
        refresh_stations()
    else:
        show_main_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])
