# -*- coding: utf-8 -*-
"""
Radio CZ/SK - Background Service
Manages cache updates and M3U playlist generation
"""

import xbmc
import xbmcaddon
import xbmcvfs
import os

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_DATA = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

# Update interval (24 hours in seconds)
UPDATE_INTERVAL = 24 * 60 * 60


class RadioCZSKService(xbmc.Monitor):
    """Background service for Radio CZ/SK"""
    
    def __init__(self):
        super().__init__()
        xbmc.log(f'{ADDON_ID}: Service started', xbmc.LOGINFO)
        
        # Ensure data directory exists
        if not xbmcvfs.exists(ADDON_DATA):
            xbmcvfs.mkdirs(ADDON_DATA)
        
        # Check if first run (no cache)
        cache_file = os.path.join(ADDON_DATA, 'stations_cache.json')
        if not os.path.exists(cache_file):
            xbmc.log(f'{ADDON_ID}: First run - cache will be created when plugin opens', xbmc.LOGINFO)
    
    def run(self):
        """Main service loop"""
        while not self.abortRequested():
            # Wait for abort or interval
            if self.waitForAbort(UPDATE_INTERVAL):
                break
            
            # Auto-update is disabled in background to avoid unnecessary API calls
            # Users can manually refresh from the plugin menu
            xbmc.log(f'{ADDON_ID}: Service heartbeat', xbmc.LOGDEBUG)
        
        xbmc.log(f'{ADDON_ID}: Service stopped', xbmc.LOGINFO)


if __name__ == '__main__':
    service = RadioCZSKService()
    service.run()
